import { useState } from 'react';
import {
  Sun, Moon, Github, FolderPlus, UploadCloud, Link2, CheckCircle2,
  Copy, Check, FileCode2, MousePointerClick, AlertTriangle, ArrowLeft, Package, Globe
} from 'lucide-react';

/* ---------- GitHub design tokens ---------- */
const T = {
  light: {
    bg: '#ffffff', subtle: '#f6f8fa', border: '#d0d7de', text: '#1f2328',
    muted: '#656d76', accent: '#0969da', green: '#1a7f37', greenBtn: '#1f883d',
    codeBg: '#f6f8fa', danger: '#d1242f', chip: '#ddf4ff',
  },
  dark: {
    bg: '#0d1117', subtle: '#161b22', border: '#30363d', text: '#e6edf3',
    muted: '#8d96a0', accent: '#2f81f7', green: '#3fb950', greenBtn: '#238636',
    codeBg: '#161b22', danger: '#f85149', chip: '#0c2d6b',
  },
};

function CopyBtn({ text, c }: { text: string; c: typeof T.light }) {
  const [ok, setOk] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setOk(true); setTimeout(() => setOk(false), 1600); }}
      className="shrink-0 rounded-md border p-1.5 transition hover:opacity-80"
      style={{ borderColor: c.border, background: c.subtle, color: ok ? c.green : c.muted }}
      aria-label="Copy"
    >
      {ok ? <Check size={14} /> : <Copy size={14} />}
    </button>
  );
}

function Code({ children, c, copy }: { children: string; c: typeof T.light; copy?: boolean }) {
  return (
    <div className="flex items-center gap-2 rounded-md border px-3 py-2.5 font-mono text-[12.5px] leading-relaxed"
      style={{ background: c.codeBg, borderColor: c.border, color: c.text }}>
      <span className="min-w-0 flex-1 break-all">{children}</span>
      {copy && <CopyBtn text={children} c={c} />}
    </div>
  );
}

/* Mock GitHub UI chrome */
function Mock({ c, children, url }: { c: typeof T.light; children: React.ReactNode; url: string }) {
  return (
    <div className="overflow-hidden rounded-lg border" style={{ borderColor: c.border }}>
      <div className="flex items-center gap-2 border-b px-3 py-2" style={{ background: c.subtle, borderColor: c.border }}>
        <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
        <span className="ml-2 flex-1 truncate rounded-md border px-2.5 py-1 font-mono text-[10.5px]"
          style={{ borderColor: c.border, background: c.bg, color: c.muted }}>{url}</span>
      </div>
      <div className="p-4" style={{ background: c.bg }}>{children}</div>
    </div>
  );
}

function GhButton({ c, green, children }: { c: typeof T.light; green?: boolean; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-md border px-3 py-1.5 text-[12px] font-semibold"
      style={green
        ? { background: c.greenBtn, borderColor: 'transparent', color: '#fff' }
        : { background: c.subtle, borderColor: c.border, color: c.text }}>
      {children}
    </span>
  );
}

export default function GithubGuide() {
  const [dark, setDark] = useState(true);
  const c = dark ? T.dark : T.light;

  const steps = [
    { id: 1, icon: Github, title: 'Sign in to GitHub' },
    { id: 2, icon: FolderPlus, title: 'Create a repository' },
    { id: 3, icon: UploadCloud, title: 'Upload your file' },
    { id: 4, icon: Link2, title: 'Get the direct link' },
    { id: 5, icon: CheckCircle2, title: 'Test your link' },
  ];

  return (
    <div className="min-h-screen transition-colors duration-300" style={{ background: c.bg, color: c.text, fontFamily: "-apple-system, 'Segoe UI', Helvetica, Arial, sans-serif" }}>
      {/* header */}
      <header className="sticky top-0 z-10 border-b backdrop-blur" style={{ borderColor: c.border, background: dark ? 'rgba(13,17,23,0.9)' : 'rgba(255,255,255,0.9)' }}>
        <div className="mx-auto flex max-w-3xl items-center justify-between px-5 py-3.5">
          <div className="flex items-center gap-3">
            <Github size={26} />
            <div className="leading-tight">
              <div className="text-[14px] font-bold">Upload a File &amp; Get a Direct Download Link</div>
              <div className="text-[11px]" style={{ color: c.muted }}>Beginner guide · personal GitHub account · 5 steps · ~4 min</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a href="/" className="flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-[11.5px] font-semibold transition hover:opacity-80"
              style={{ borderColor: c.border, background: c.subtle, color: c.text }}>
              <ArrowLeft size={13} /> <span className="hidden sm:inline">Dashboard</span>
            </a>
            <button onClick={() => setDark(!dark)} className="rounded-md border p-2 transition hover:opacity-80"
              style={{ borderColor: c.border, background: c.subtle, color: c.text }} aria-label="Toggle theme">
              {dark ? <Sun size={15} /> : <Moon size={15} />}
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-5 pb-20">
        {/* progress strip */}
        <nav className="my-6 flex flex-wrap gap-2">
          {steps.map((s) => (
            <a key={s.id} href={`#step-${s.id}`}
              className="flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-[11.5px] font-semibold transition hover:opacity-80"
              style={{ borderColor: c.border, background: c.subtle, color: c.text }}>
              <span className="grid h-4.5 w-4.5 place-items-center rounded-full text-[10px] font-bold"
                style={{ background: c.accent, color: '#fff', width: 18, height: 18 }}>{s.id}</span>
              {s.title}
            </a>
          ))}
        </nav>

        {/* STEP 1 */}
        <section id="step-1" className="scroll-mt-20 py-5">
          <div className="mb-3 flex items-center gap-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[15px] font-bold" style={{ background: c.accent, color: '#fff' }}>1</span>
            <h2 className="text-[19px] font-bold">Sign in to GitHub</h2>
          </div>
          <ol className="ml-12 list-decimal space-y-1.5 text-[13.5px] leading-relaxed" style={{ color: c.muted }}>
            <li>Go to <span className="font-semibold" style={{ color: c.accent }}>github.com</span> and click <b style={{ color: c.text }}>Sign in</b> (top-right corner).</li>
            <li>No account yet? Click <b style={{ color: c.text }}>Sign up</b> — a free personal account is all you need.</li>
          </ol>
        </section>

        {/* STEP 2 */}
        <section id="step-2" className="scroll-mt-20 border-t py-5" style={{ borderColor: c.border }}>
          <div className="mb-3 flex items-center gap-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[15px] font-bold" style={{ background: c.accent, color: '#fff' }}>2</span>
            <h2 className="text-[19px] font-bold">Create a repository</h2>
          </div>
          <ol className="ml-12 list-decimal space-y-1.5 text-[13.5px] leading-relaxed" style={{ color: c.muted }}>
            <li>Click the <b style={{ color: c.text }}>+</b> icon in the top-right corner → choose <b style={{ color: c.text }}>New repository</b>.</li>
            <li>Enter a short <b style={{ color: c.text }}>Repository name</b>, e.g. <code className="rounded px-1.5 py-0.5 font-mono text-[12px]" style={{ background: c.codeBg, border: `1px solid ${c.border}` }}>my-files</code>.</li>
            <li>Select <b style={{ color: c.text }}>Public</b> — required so your download link works for everyone.</li>
            <li>Tick <b style={{ color: c.text }}>Add a README file</b>, then click the green <b style={{ color: c.text }}>Create repository</b> button.</li>
          </ol>
          <div className="ml-12 mt-4">
            <Mock c={c} url="github.com/new">
              <div className="space-y-3">
                <div>
                  <div className="mb-1 text-[12px] font-semibold">Repository name *</div>
                  <span className="inline-block rounded-md border px-3 py-1.5 font-mono text-[12.5px]" style={{ borderColor: c.border, background: c.subtle }}>my-files</span>
                  <span className="ml-2 text-[12px]" style={{ color: c.green }}>✓ my-files is available.</span>
                </div>
                <div className="flex items-center gap-2 text-[12.5px]">
                  <span className="grid h-4 w-4 place-items-center rounded-full border-4" style={{ borderColor: c.accent }} />
                  <Globe size={14} style={{ color: c.muted }} /> <b>Public</b>
                  <span style={{ color: c.muted }}>— anyone on the internet can see this repository</span>
                </div>
                <GhButton c={c} green>Create repository</GhButton>
              </div>
            </Mock>
          </div>
        </section>

        {/* STEP 3 */}
        <section id="step-3" className="scroll-mt-20 border-t py-5" style={{ borderColor: c.border }}>
          <div className="mb-3 flex items-center gap-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[15px] font-bold" style={{ background: c.accent, color: '#fff' }}>3</span>
            <h2 className="text-[19px] font-bold">Upload your file</h2>
          </div>
          <ol className="ml-12 list-decimal space-y-1.5 text-[13.5px] leading-relaxed" style={{ color: c.muted }}>
            <li>On your new repository page, click <b style={{ color: c.text }}>Add file</b> → <b style={{ color: c.text }}>Upload files</b>.</li>
            <li><b style={{ color: c.text }}>Drag &amp; drop</b> your file into the box, or click <b style={{ color: c.text }}>choose your files</b>.</li>
            <li>Scroll down and click the green <b style={{ color: c.text }}>Commit changes</b> button. Done — your file is now stored on GitHub.</li>
          </ol>
          <div className="ml-12 mt-4">
            <Mock c={c} url="github.com/yourname/my-files/upload/main">
              <div className="grid place-items-center gap-2 rounded-lg border-2 border-dashed py-8 text-center" style={{ borderColor: c.border }}>
                <UploadCloud size={30} style={{ color: c.muted }} />
                <div className="text-[13.5px] font-semibold">Drag files here to add them to your repository</div>
                <div className="text-[12px]" style={{ color: c.muted }}>Or <span style={{ color: c.accent }} className="font-semibold">choose your files</span></div>
              </div>
              <div className="mt-3 flex items-center justify-between rounded-md border px-3 py-2" style={{ borderColor: c.border, background: c.subtle }}>
                <span className="flex items-center gap-2 font-mono text-[12px]"><FileCode2 size={14} style={{ color: c.muted }} /> my-app-v1.0.zip</span>
                <GhButton c={c} green>Commit changes</GhButton>
              </div>
            </Mock>
          </div>
          <div className="ml-12 mt-3 flex items-start gap-2 rounded-md border px-3 py-2.5 text-[12.5px] leading-relaxed"
            style={{ borderColor: dark ? '#3d2e12' : '#d4a72c55', background: dark ? '#2d210b' : '#fff8c5', color: c.text }}>
            <AlertTriangle size={15} className="mt-0.5 shrink-0" style={{ color: dark ? '#d29922' : '#9a6700' }} />
            <span><b>Size limit:</b> the web uploader accepts files up to <b>25 MB</b> (100 MB via Git). For bigger files, use <b>Releases</b> — see the tip at the end (up to 2 GB per file).</span>
          </div>
        </section>

        {/* STEP 4 */}
        <section id="step-4" className="scroll-mt-20 border-t py-5" style={{ borderColor: c.border }}>
          <div className="mb-3 flex items-center gap-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[15px] font-bold" style={{ background: c.accent, color: '#fff' }}>4</span>
            <h2 className="text-[19px] font-bold">Get the direct download link</h2>
          </div>
          <ol className="ml-12 list-decimal space-y-1.5 text-[13.5px] leading-relaxed" style={{ color: c.muted }}>
            <li>In the repository file list, <b style={{ color: c.text }}>click your file's name</b> to open it.</li>
            <li>Find the <b style={{ color: c.text }}>Raw</b> button (top-right of the file viewer).</li>
            <li><b style={{ color: c.text }}>Right-click Raw → “Copy link address”</b>. That URL is your direct download link.</li>
          </ol>
          <div className="ml-12 mt-4">
            <Mock c={c} url="github.com/yourname/my-files/blob/main/my-app-v1.0.zip">
              <div className="flex items-center justify-between rounded-t-md border px-3 py-2" style={{ borderColor: c.border, background: c.subtle }}>
                <span className="flex items-center gap-2 font-mono text-[12px]"><FileCode2 size={14} style={{ color: c.muted }} /> my-app-v1.0.zip <span style={{ color: c.muted }}>· 4.2 MB</span></span>
                <span className="relative inline-flex">
                  <GhButton c={c}>Raw</GhButton>
                  <MousePointerClick size={17} className="absolute -bottom-2 -right-2" style={{ color: c.accent }} />
                </span>
              </div>
              <div className="rounded-b-md border border-t-0 px-3 py-5 text-center text-[12px]" style={{ borderColor: c.border, color: c.muted }}>
                (binary file — clicking Raw downloads it directly)
              </div>
            </Mock>
          </div>
          <div className="ml-12 mt-4 space-y-2">
            <div className="text-[12.5px] font-semibold">Your link will follow this pattern — just swap in your details:</div>
            <Code c={c} copy>https://raw.githubusercontent.com/YOURNAME/my-files/main/my-app-v1.0.zip</Code>
            <div className="text-[12px]" style={{ color: c.muted }}>
              <b style={{ color: c.text }}>YOURNAME</b> = your GitHub username · <b style={{ color: c.text }}>my-files</b> = repository · <b style={{ color: c.text }}>main</b> = branch · then the file name.
            </div>
            <div className="text-[12.5px] font-semibold pt-1">Shortcut that always works (auto-redirects to raw):</div>
            <Code c={c} copy>https://github.com/YOURNAME/my-files/raw/main/my-app-v1.0.zip</Code>
          </div>
        </section>

        {/* STEP 5 */}
        <section id="step-5" className="scroll-mt-20 border-t py-5" style={{ borderColor: c.border }}>
          <div className="mb-3 flex items-center gap-3">
            <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-[15px] font-bold" style={{ background: c.green, color: '#fff' }}>5</span>
            <h2 className="text-[19px] font-bold">Test your link</h2>
          </div>
          <ol className="ml-12 list-decimal space-y-1.5 text-[13.5px] leading-relaxed" style={{ color: c.muted }}>
            <li>Paste the link into a <b style={{ color: c.text }}>private/incognito window</b> (this checks it works while signed out).</li>
            <li>The file should download immediately — no GitHub page, no sign-in prompt.</li>
            <li>If you see a 404: confirm the repository is <b style={{ color: c.text }}>Public</b> and the file name matches exactly (links are case-sensitive).</li>
          </ol>
          <div className="ml-12 mt-4 flex items-center gap-2.5 rounded-md border px-4 py-3"
            style={{ borderColor: dark ? '#1f4429' : '#aceebb', background: dark ? '#12261e' : '#dafbe1' }}>
            <CheckCircle2 size={18} style={{ color: c.green }} />
            <span className="text-[13px] font-semibold">That's it — you now have a shareable direct download link, free, hosted by GitHub.</span>
          </div>
        </section>

        {/* bonus tips */}
        <section className="border-t py-5" style={{ borderColor: c.border }}>
          <h2 className="mb-3 flex items-center gap-2 text-[16px] font-bold"><Package size={17} style={{ color: c.accent }} /> Good to know</h2>
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              { t: 'Large files? Use Releases', d: 'Repo → Releases → “Draft a new release” → attach files (up to 2 GB each). Each attachment gets its own permanent download URL.' },
              { t: 'Updating a file', d: 'Upload a file with the same name and commit — the raw link stays identical and always serves the newest version.' },
              { t: 'Links are case-sensitive', d: 'My-File.zip and my-file.zip are different URLs. Prefer lowercase names with dashes, no spaces.' },
              { t: 'Private repos won’t work', d: 'Raw links from private repositories require sign-in and expire. Keep the repo Public for shareable links.' },
            ].map((x) => (
              <div key={x.t} className="rounded-lg border p-4" style={{ borderColor: c.border, background: c.subtle }}>
                <div className="text-[13px] font-bold">{x.t}</div>
                <div className="mt-1 text-[12.5px] leading-relaxed" style={{ color: c.muted }}>{x.d}</div>
              </div>
            ))}
          </div>
        </section>

        <footer className="border-t pt-5 text-center text-[11.5px]" style={{ borderColor: c.border, color: c.muted }}>
          Made for beginners · GitHub is a trademark of GitHub, Inc. · This guide is unofficial
        </footer>
      </main>
    </div>
  );
}
