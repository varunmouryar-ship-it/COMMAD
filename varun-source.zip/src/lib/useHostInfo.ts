import { useEffect, useState } from 'react';

export interface HostInfo {
  gpu: string;
  gpuVendor: string;
  cpuThreads: number | null;
  deviceMemory: number | null; // GB (browser caps at 8)
  platform: string;
  osGuess: string;
  browser: string;
  screenRes: string;
  pixelRatio: number;
  colorDepth: number;
  touch: boolean;
  netType: string;
  netDownlink: number | null;
  netRtt: number | null;
  battery: { level: number; charging: boolean } | null;
  language: string;
  timezone: string;
  online: boolean;
}

function detectGpu(): { gpu: string; vendor: string } {
  try {
    const canvas = document.createElement('canvas');
    const gl = (canvas.getContext('webgl2') || canvas.getContext('webgl')) as WebGLRenderingContext | null;
    if (!gl) return { gpu: 'Not accessible', vendor: '—' };
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (ext) {
      return {
        gpu: String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)),
        vendor: String(gl.getParameter(ext.UNMASKED_VENDOR_WEBGL)),
      };
    }
    return { gpu: String(gl.getParameter(gl.RENDERER)), vendor: String(gl.getParameter(gl.VENDOR)) };
  } catch {
    return { gpu: 'Not accessible', vendor: '—' };
  }
}

function detectOs(): string {
  const ua = navigator.userAgent;
  if (/Windows NT 10/.test(ua)) return 'Windows 10 / 11';
  if (/Windows/.test(ua)) return 'Windows';
  if (/Mac OS X/.test(ua)) return 'macOS';
  if (/Android/.test(ua)) return 'Android';
  if (/iPhone|iPad/.test(ua)) return 'iOS / iPadOS';
  if (/CrOS/.test(ua)) return 'ChromeOS';
  if (/Linux/.test(ua)) return 'Linux';
  return 'Unknown';
}

function detectBrowser(): string {
  const ua = navigator.userAgent;
  if (/Edg\//.test(ua)) return `Edge ${ua.match(/Edg\/([\d.]+)/)?.[1] ?? ''}`;
  if (/OPR\//.test(ua)) return `Opera ${ua.match(/OPR\/([\d.]+)/)?.[1] ?? ''}`;
  if (/Chrome\//.test(ua)) return `Chrome ${ua.match(/Chrome\/([\d.]+)/)?.[1]?.split('.')[0] ?? ''}`;
  if (/Firefox\//.test(ua)) return `Firefox ${ua.match(/Firefox\/([\d.]+)/)?.[1] ?? ''}`;
  if (/Safari\//.test(ua)) return 'Safari';
  return 'Unknown';
}

export function useHostInfo(): HostInfo {
  const [info, setInfo] = useState<HostInfo>(() => {
    const { gpu, vendor } = detectGpu();
    const nav = navigator as Navigator & {
      deviceMemory?: number;
      connection?: { effectiveType?: string; downlink?: number; rtt?: number };
    };
    return {
      gpu,
      gpuVendor: vendor,
      cpuThreads: navigator.hardwareConcurrency ?? null,
      deviceMemory: nav.deviceMemory ?? null,
      platform: navigator.platform || '—',
      osGuess: detectOs(),
      browser: detectBrowser(),
      screenRes: `${screen.width}×${screen.height}`,
      pixelRatio: window.devicePixelRatio,
      colorDepth: screen.colorDepth,
      touch: navigator.maxTouchPoints > 0,
      netType: nav.connection?.effectiveType ?? 'unknown',
      netDownlink: nav.connection?.downlink ?? null,
      netRtt: nav.connection?.rtt ?? null,
      battery: null,
      language: navigator.language,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
      online: navigator.onLine,
    };
  });

  useEffect(() => {
    const nav = navigator as Navigator & { getBattery?: () => Promise<{ level: number; charging: boolean }> };
    nav.getBattery?.().then((b) => {
      setInfo((i) => ({ ...i, battery: { level: b.level, charging: b.charging } }));
    }).catch(() => {});
  }, []);

  return info;
}
