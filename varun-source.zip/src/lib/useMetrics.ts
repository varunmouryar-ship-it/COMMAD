import { useEffect, useRef, useState } from 'react';

export interface LiveMetrics {
  cpu: number;
  gpu: number;
  ram: number;
  netDown: number;
  netUp: number;
  cpuTemp: number;
  gpuTemp: number;
  cpuHistory: number[];
  gpuHistory: number[];
  ramHistory: number[];
  netHistory: number[];
  uptime: number;
}

const LEN = 48;

function drift(v: number, min: number, max: number, vol: number) {
  const next = v + (Math.random() - 0.5) * vol + (Math.sin(Date.now() / 9000) * vol) / 3;
  return Math.min(max, Math.max(min, next));
}

export function useMetrics(): LiveMetrics {
  const ref = useRef({
    cpu: 34, gpu: 22, ram: 58, netDown: 42, netUp: 8, cpuTemp: 52, gpuTemp: 46,
    cpuHistory: Array.from({ length: LEN }, () => 25 + Math.random() * 25),
    gpuHistory: Array.from({ length: LEN }, () => 15 + Math.random() * 20),
    ramHistory: Array.from({ length: LEN }, () => 50 + Math.random() * 15),
    netHistory: Array.from({ length: LEN }, () => 20 + Math.random() * 50),
    uptime: 348_720,
  });
  const [, force] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      const m = ref.current;
      m.cpu = drift(m.cpu, 8, 96, 9);
      m.gpu = drift(m.gpu, 4, 92, 7);
      m.ram = drift(m.ram, 38, 88, 3);
      m.netDown = drift(m.netDown, 2, 240, 28);
      m.netUp = drift(m.netUp, 1, 40, 5);
      m.cpuTemp = drift(m.cpuTemp, 40, 84, 2.5);
      m.gpuTemp = drift(m.gpuTemp, 36, 78, 2);
      m.cpuHistory = [...m.cpuHistory.slice(1), m.cpu];
      m.gpuHistory = [...m.gpuHistory.slice(1), m.gpu];
      m.ramHistory = [...m.ramHistory.slice(1), m.ram];
      m.netHistory = [...m.netHistory.slice(1), m.netDown];
      m.uptime += 1.5;
      force((n) => n + 1);
    }, 1500);
    return () => clearInterval(t);
  }, []);

  return ref.current;
}

export function fmtUptime(s: number) {
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return `${d}d ${h}h ${m}m`;
}
