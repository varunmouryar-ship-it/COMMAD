export interface Device {
  id: number;
  name: string;
  type: string;
  status: string;
  temperature: number;
  usage: number;
  health: number;
  driver_version: string;
  firmware: string;
  os_binding: string;
}

export interface Alert {
  id: number;
  severity: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
  source: string;
  resolved: boolean;
  created_at: string;
}

export interface FirmwareUpdate {
  id: number;
  component: string;
  vendor: string;
  current_version: string;
  available_version: string;
  size_mb: number;
  status: 'up-to-date' | 'available' | 'installing' | 'installed';
  critical: boolean;
  released: string;
  changelog: string;
}

export interface DiagnosticTest {
  id: number;
  test_name: string;
  category: string;
  status: 'idle' | 'running' | 'passed' | 'failed';
  result: string;
  duration_ms: number;
  ran_at: string | null;
}

export interface BiosSetting {
  id: number;
  setting_key: string;
  label: string;
  category: string;
  value_type: 'bool' | 'select' | 'number';
  value: string;
  options: string[] | null;
  description: string;
}

export async function apiGet<T>(path: string): Promise<T> {
  const res = await fetch(path);
  if (!res.ok) throw new Error(`${path} → ${res.status}`);
  return res.json();
}

export async function apiPut<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(path, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`${path} → ${res.status}`);
  return res.json();
}
