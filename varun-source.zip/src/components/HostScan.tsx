import Panel from './Panel';
import { useHostInfo } from '../lib/useHostInfo';
import { ScanLine, MonitorSmartphone, Cpu, MemoryStick, Globe, BatteryCharging, Wifi, Info } from 'lucide-react';

export default function HostScan() {
  const h = useHostInfo();

  const rows: { icon: typeof Cpu; label: string; value: string; real: boolean }[] = [
    { icon: MonitorSmartphone, label: 'GPU (original unit)', value: h.gpu, real: true },
    { icon: Cpu, label: 'CPU Logical Threads', value: h.cpuThreads ? `${h.cpuThreads} threads` : 'Not exposed', real: !!h.cpuThreads },
    { icon: MemoryStick, label: 'Device Memory Class', value: h.deviceMemory ? `≥ ${h.deviceMemory} GB (browser-capped)` : 'Not exposed', real: !!h.deviceMemory },
    { icon: Globe, label: 'Operating System', value: `${h.osGuess} · ${h.browser}`, real: true },
    { icon: ScanLine, label: 'Display', value: `${h.screenRes} @ ${h.pixelRatio}x · ${h.colorDepth}-bit${h.touch ? ' · touch' : ''}`, real: true },
    { icon: Wifi, label: 'Network Link', value: h.netDownlink ? `${h.netType} · ~${h.netDownlink} Mb/s · ${h.netRtt}ms RTT` : h.online ? 'online' : 'offline', real: true },
    { icon: BatteryCharging, label: 'Battery', value: h.battery ? `${Math.round(h.battery.level * 100)}%${h.battery.charging ? ' · charging' : ''}` : 'Not exposed / desktop', real: !!h.battery },
    { icon: Globe, label: 'Locale / Timezone', value: `${h.language} · ${h.timezone}`, real: true },
  ];

  return (
    <Panel
      title="Host Hardware Scan"
      tag="real · this machine"
      action={
        <span className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-wider text-[var(--ok)]">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--ok)] animate-pulse" /> live probe
        </span>
      }
    >
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        {rows.map(({ icon: Icon, label, value, real }) => (
          <div key={label} className="flex items-center gap-3 rounded-md border border-[var(--line)] bg-black/25 px-3 py-2.5">
            <Icon size={15} className={real ? 'shrink-0 text-[var(--neon)]' : 'shrink-0 text-slate-600'} />
            <div className="min-w-0">
              <p className="font-mono text-[9px] uppercase tracking-widest text-slate-500">{label}</p>
              <p className={`truncate text-[12px] font-semibold ${real ? 'text-slate-200' : 'text-slate-500'}`} title={value}>{value}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex items-start gap-2 rounded-md border border-[var(--warn)]/25 bg-[var(--warn)]/[0.06] px-3 py-2.5">
        <Info size={13} className="mt-0.5 shrink-0 text-[var(--warn)]" />
        <p className="text-[10.5px] leading-relaxed text-slate-400">
          These values are read live from <span className="text-slate-200">your actual machine</span> via browser APIs (WebGL, hardwareConcurrency, Network Information).
          Browsers sandbox deeper hardware — BIOS version, temperatures, fan RPM, serials and exact RAM size are not accessible from a web page, so the other panels display simulated enterprise telemetry.
        </p>
      </div>
    </Panel>
  );
}
