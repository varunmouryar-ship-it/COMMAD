import type { ReactNode } from 'react';

export default function Panel({ title, tag, action, children, className = '' }: { title: string; tag?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-lg border border-[var(--line)] bg-[var(--panel)] shadow-[0_2px_16px_rgba(0,0,0,0.35)] ${className}`}>
      <header className="flex items-center justify-between border-b border-[var(--line)] px-4 py-3">
        <div className="flex items-center gap-2.5">
          <span className="h-3.5 w-[2.5px] rounded-full bg-[var(--neon)] shadow-[0_0_6px_var(--neon)]" />
          <h2 className="font-display text-[13px] font-semibold uppercase tracking-[0.12em] text-slate-200">{title}</h2>
          {tag && <span className="rounded border border-[var(--line)] bg-black/30 px-1.5 py-0.5 font-mono text-[9px] uppercase tracking-wider text-slate-500">{tag}</span>}
        </div>
        {action}
      </header>
      <div className="p-4">{children}</div>
    </section>
  );
}
