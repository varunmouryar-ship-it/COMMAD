import { Shield, Wifi, Bell, MonitorCheck, Download, CheckCircle2 } from 'lucide-react';
import type { LiveMetrics } from '../lib/useMetrics';
import { fmtUptime } from '../lib/useMetrics';
import { useInstall } from '../lib/useInstall';

export default function TopBar({ m, alertCount }: { m: LiveMetrics; alertCount: number }) {
  const { canInstall, installed, install } = useInstall();
  return (
    <header className="flex h-16 shrink-0 items-center justify-between border-b border-[var(--line)] bg-[var(--panel-deep)]/80 px-4 lg:px-6 backdrop-blur">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <MonitorCheck size={16} className="text-[var(--neon)]" />
          <span className="font-display text-sm font-semibold text-white">WORKSTATION-01</span>
        </div>
        <span className="hidden md:inline-flex items-center gap-1.5 rounded-full border border-[var(--ok)]/30 bg-[var(--ok)]/10 px-2.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider text-[var(--ok)]">
          <span className="h-1.5 w-1.5 rounded-full bg-[var(--ok)] animate-pulse" /> Online
        </span>
      </div>

      <div className="hidden md:flex items-center gap-5 font-mono text-[11px] text-slate-400 tabular-nums">
        <span>CPU <b className="text-[var(--neon)]">{Math.round(m.cpu)}%</b></span>
        <span>GPU <b className="text-[var(--neon)]">{Math.round(m.gpu)}%</b></span>
        <span>RAM <b className="text-[var(--neon)]">{Math.round(m.ram)}%</b></span>
        <span className="hidden lg:inline">UPTIME <b className="text-slate-200">{fmtUptime(m.uptime)}</b></span>
      </div>

      <div className="flex items-center gap-3">
        {canInstall && (
          <button
            onClick={install}
            className="flex items-center gap-1.5 rounded-md border border-[var(--neon)]/40 bg-[var(--neon)]/10 px-2.5 py-1.5 text-[11px] font-semibold text-[var(--neon)] transition hover:bg-[var(--neon)]/20 hover:shadow-[0_0_12px_rgba(0,180,255,0.3)]"
          >
            <Download size={13} /> <span className="hidden sm:inline">Install App</span>
          </button>
        )}
        {installed && (
          <span className="hidden sm:flex items-center gap-1.5 text-[10px] font-mono uppercase tracking-wider text-[var(--ok)]">
            <CheckCircle2 size={12} /> Desktop
          </span>
        )}
        <div className="hidden sm:flex items-center gap-1.5 text-[11px] text-slate-400 font-mono">
          <Wifi size={14} className="text-[var(--ok)]" />
          <span className="tabular-nums">{Math.round(m.netDown)} Mb/s</span>
        </div>
        <div className="relative grid h-8 w-8 place-items-center rounded-md border border-[var(--line)] bg-[var(--panel)] text-slate-300">
          <Bell size={15} />
          {alertCount > 0 && (
            <span className="absolute -right-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-[var(--danger)] px-1 text-[9px] font-bold text-white shadow-[0_0_8px_rgba(255,64,80,0.6)]">
              {alertCount}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1.5 rounded-md border border-[var(--line)] bg-[var(--panel)] px-2.5 py-1.5 text-[11px] text-slate-300">
          <Shield size={14} className="text-[var(--neon)]" />
          <span className="hidden sm:inline">Secure Boot</span>
        </div>
      </div>
    </header>
  );
}
