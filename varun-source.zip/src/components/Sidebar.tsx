import { LayoutDashboard, Cpu, HardDriveDownload, Settings2, TerminalSquare, Activity, Zap, ArrowLeftRight, BookOpen } from 'lucide-react';
import { Link } from 'react-router-dom';

export type View = 'overview' | 'osshift' | 'devices' | 'firmware' | 'bios' | 'terminal' | 'diagnostics';

const items: { id: View; label: string; icon: typeof Cpu }[] = [
  { id: 'overview', label: 'Command Center', icon: LayoutDashboard },
  { id: 'osshift', label: 'OS Shift', icon: ArrowLeftRight },
  { id: 'devices', label: 'Device Monitor', icon: Cpu },
  { id: 'firmware', label: 'BIOS / Firmware', icon: HardDriveDownload },
  { id: 'bios', label: 'BIOS Control', icon: Settings2 },
  { id: 'terminal', label: 'CMD / Terminal', icon: TerminalSquare },
  { id: 'diagnostics', label: 'Diagnostics', icon: Activity },
];

export default function Sidebar({ view, setView }: { view: View; setView: (v: View) => void }) {
  return (
    <aside className="flex h-full w-[72px] lg:w-60 shrink-0 flex-col border-r border-[var(--line)] bg-[var(--panel-deep)]">
      <div className="flex items-center gap-3 px-4 lg:px-5 h-16 border-b border-[var(--line)]">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-gradient-to-br from-[var(--neon)] to-[#0060c8] shadow-[0_0_16px_rgba(0,180,255,0.4)]">
          <Zap size={18} className="text-black" strokeWidth={2.5} />
        </div>
        <div className="hidden lg:block leading-tight">
          <div className="font-display text-[15px] font-bold tracking-wide text-white">COMM<span className="text-[var(--neon)]">AND</span></div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-slate-500">System Control</div>
        </div>
      </div>

      <nav className="flex-1 space-y-1 p-2 lg:p-3">
        {items.map(({ id, label, icon: Icon }) => {
          const active = view === id;
          return (
            <button
              key={id}
              onClick={() => setView(id)}
              className={`group relative flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-[13px] font-medium transition-all ${
                active ? 'bg-[rgba(0,180,255,0.1)] text-[var(--neon)]' : 'text-slate-400 hover:bg-white/[0.04] hover:text-slate-200'
              }`}
            >
              {active && <span className="absolute left-0 top-1/2 h-5 w-[2.5px] -translate-y-1/2 rounded-full bg-[var(--neon)] shadow-[0_0_8px_var(--neon)]" />}
              <Icon size={17} strokeWidth={active ? 2.2 : 1.8} className="shrink-0 mx-auto lg:mx-0" />
              <span className="hidden lg:inline">{label}</span>
            </button>
          );
        })}
      </nav>

      <div className="border-t border-[var(--line)] p-2 lg:p-3">
        <Link
          to="/github-guide"
          className="group flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-[13px] font-medium text-slate-400 transition-all hover:bg-white/[0.04] hover:text-slate-200"
        >
          <BookOpen size={17} strokeWidth={1.8} className="shrink-0 mx-auto lg:mx-0" />
          <span className="hidden lg:inline">GitHub Guide</span>
        </Link>
      </div>

      <div className="hidden lg:block border-t border-[var(--line)] p-4">
        <div className="rounded-md border border-[var(--line)] bg-[var(--panel)] p-3">
          <div className="flex items-center justify-between text-[10px] uppercase tracking-widest text-slate-500">
            <span>OS Bridge</span>
            <span className="flex items-center gap-1.5 text-[var(--ok)]"><span className="h-1.5 w-1.5 rounded-full bg-[var(--ok)] animate-pulse" />Linked</span>
          </div>
          <div className="mt-2 space-y-1 text-[11px] text-slate-400">
            <div className="flex justify-between"><span>Windows 11 Pro</span><span className="text-slate-300 tabular-nums">24H2</span></div>
            <div className="flex justify-between"><span>Shift OS</span><span className="text-slate-300 tabular-nums">v3.8.1</span></div>
          </div>
        </div>
      </div>
    </aside>
  );
}
