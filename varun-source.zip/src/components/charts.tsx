export function AreaChart({ data, color = 'var(--neon)', height = 72, max = 100 }: { data: number[]; color?: string; height?: number; max?: number }) {
  const w = 300;
  const pts = data.map((v, i) => `${(i / (data.length - 1)) * w},${height - (Math.min(v, max) / max) * (height - 6) - 2}`);
  const id = `g${color.replace(/[^a-z0-9]/gi, '')}`;
  return (
    <svg viewBox={`0 0 ${w} ${height}`} preserveAspectRatio="none" className="w-full" style={{ height }}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {[0.25, 0.5, 0.75].map((f) => (
        <line key={f} x1="0" y1={height * f} x2={w} y2={height * f} stroke="#ffffff" strokeOpacity="0.05" strokeWidth="1" />
      ))}
      <polygon points={`0,${height} ${pts.join(' ')} ${w},${height}`} fill={`url(#${id})`} />
      <polyline points={pts.join(' ')} fill="none" stroke={color} strokeWidth="1.6" strokeLinejoin="round" />
    </svg>
  );
}

export function Ring({ value, size = 84, color = 'var(--neon)', label, sub }: { value: number; size?: number; color?: string; label: string; sub?: string }) {
  const r = size / 2 - 7;
  const c = 2 * Math.PI * r;
  return (
    <div className="flex flex-col items-center gap-1">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#1a222e" strokeWidth="6" />
          <circle
            cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth="6"
            strokeDasharray={c} strokeDashoffset={c - (Math.min(value, 100) / 100) * c}
            strokeLinecap="round" style={{ transition: 'stroke-dashoffset 1.2s ease', filter: `drop-shadow(0 0 5px ${color})` }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center font-display text-lg font-semibold tabular-nums" style={{ color }}>
          {Math.round(value)}
          <span className="text-[10px] text-slate-500 mt-0.5">%</span>
        </div>
      </div>
      <div className="text-[11px] uppercase tracking-widest text-slate-400">{label}</div>
      {sub && <div className="text-[10px] text-slate-500 tabular-nums">{sub}</div>}
    </div>
  );
}

export function Meter({ value, color = 'var(--neon)' }: { value: number; color?: string }) {
  return (
    <div className="h-1.5 w-full rounded-full bg-[#1a222e] overflow-hidden">
      <div
        className="h-full rounded-full"
        style={{ width: `${Math.min(value, 100)}%`, background: color, boxShadow: `0 0 8px ${color}`, transition: 'width 1.2s ease' }}
      />
    </div>
  );
}
