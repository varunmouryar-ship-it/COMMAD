import { useState } from 'react';
import Panel from '../components/Panel';
import { apiPut, type DiagnosticTest } from '../lib/api';
import { PlayCircle, CheckCircle2, XCircle, Loader2, Activity } from 'lucide-react';

export default function Diagnostics({ tests, refresh }: { tests: DiagnosticTest[]; refresh: () => void }) {
  const [running, setRunning] = useState<Set<number>>(new Set());

  const runTest = async (t: DiagnosticTest) => {
    setRunning((s) => new Set(s).add(t.id));
    await apiPut('/api/diagnostics', { id: t.id, status: 'running' });
    refresh();
    const dur = 1500 + Math.random() * 2500;
    setTimeout(async () => {
      const pass = Math.random() > 0.12;
      await apiPut('/api/diagnostics', {
        id: t.id,
        status: pass ? 'passed' : 'failed',
        result: pass ? 'All checks completed within nominal thresholds.' : 'Threshold deviation detected — review subsystem logs.',
        duration_ms: Math.round(dur),
        ran_at: new Date().toISOString(),
      });
      setRunning((s) => { const n = new Set(s); n.delete(t.id); return n; });
      refresh();
    }, dur);
  };

  const runAll = () => tests.forEach((t, i) => setTimeout(() => runTest(t), i * 350));

  const passed = tests.filter((t) => t.status === 'passed').length;
  const failed = tests.filter((t) => t.status === 'failed').length;

  const statusUi = (t: DiagnosticTest) => {
    const isRunning = t.status === 'running' || running.has(t.id);
    if (isRunning) return <span className="flex items-center gap-1.5 font-mono text-[10px] font-bold uppercase text-[var(--neon)]"><Loader2 size={13} className="animate-spin" /> Running</span>;
    if (t.status === 'passed') return <span className="flex items-center gap-1.5 font-mono text-[10px] font-bold uppercase text-[var(--ok)]"><CheckCircle2 size={13} /> Passed</span>;
    if (t.status === 'failed') return <span className="flex items-center gap-1.5 font-mono text-[10px] font-bold uppercase text-[var(--danger)]"><XCircle size={13} /> Failed</span>;
    return <span className="font-mono text-[10px] font-bold uppercase text-slate-500">Idle</span>;
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-[var(--line)] bg-[var(--panel)] px-4 py-3">
        <div className="flex items-center gap-6 font-mono text-[11px] tabular-nums">
          <span className="flex items-center gap-2 text-slate-400"><Activity size={14} className="text-[var(--neon)]" /> {tests.length} test suites</span>
          <span className="text-[var(--ok)]">{passed} passed</span>
          <span className="text-[var(--danger)]">{failed} failed</span>
        </div>
        <button onClick={runAll} className="flex items-center gap-2 rounded-md border border-[var(--neon)]/40 bg-[var(--neon)]/10 px-4 py-1.5 font-mono text-[11px] font-bold uppercase tracking-wider text-[var(--neon)] transition hover:bg-[var(--neon)]/20 hover:shadow-[0_0_14px_rgba(0,180,255,0.3)]">
          <PlayCircle size={14} /> Run Full Sweep
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {tests.map((t) => (
          <Panel key={t.id} title={t.test_name} tag={t.category} action={statusUi(t)}>
            <p className="min-h-8 text-[11.5px] text-slate-500">{t.result || 'Not yet executed in this session.'}</p>
            <div className="mt-3 flex items-center justify-between border-t border-[var(--line)] pt-3">
              <span className="font-mono text-[10px] text-slate-500 tabular-nums">
                {t.ran_at ? `last: ${new Date(t.ran_at).toLocaleTimeString()} · ${t.duration_ms}ms` : 'no run history'}
              </span>
              <button
                onClick={() => runTest(t)}
                disabled={running.has(t.id) || t.status === 'running'}
                className="rounded-md border border-[var(--line)] px-3 py-1 font-mono text-[10px] font-bold uppercase tracking-wider text-slate-300 transition hover:border-[var(--neon)]/40 hover:text-[var(--neon)] disabled:opacity-40"
              >
                Execute
              </button>
            </div>
          </Panel>
        ))}
      </div>
    </div>
  );
}
