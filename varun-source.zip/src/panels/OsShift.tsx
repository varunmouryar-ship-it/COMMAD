import { useCallback, useEffect, useState } from 'react';
import Panel from '../components/Panel';
import { apiGet } from '../lib/api';
import { ArrowLeftRight, MonitorCog, Layers, Loader2, ShieldCheck, Cable, History } from 'lucide-react';

export interface OsSwitch {
  id: number;
  from_os: string;
  to_os: string;
  mode: string;
  duration_ms: number;
  initiated_by: string;
  created_at: string;
}

const MODES = ['Warm Bridge', 'Instant Switch', 'Cold Boot'] as const;

const osMeta: Record<string, { color: string; kernel: string; session: string }> = {
  'Windows 11': { color: 'var(--neon)', kernel: 'NT 10.0.26100', session: 'Desktop · DWM composited' },
  'Shift OS': { color: '#7c5cff', kernel: 'shift-3.8.1-lts', session: 'Wayland · bridge-linked' },
};

const PHASES = [
  'Freezing user session…',
  'Syncing device state over bridge…',
  'Handing off GPU + display pipeline…',
  'Resuming target kernel…',
];

export default function OsShift() {
  const [history, setHistory] = useState<OsSwitch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [mode, setMode] = useState<string>('Warm Bridge');
  const [shifting, setShifting] = useState(false);
  const [phase, setPhase] = useState(0);

  const fetchHistory = useCallback(async () => {
    try {
      const data = await apiGet<OsSwitch[]>('/api/osshift');
      setHistory(data);
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchHistory(); }, [fetchHistory]);

  const activeOs = history[0]?.to_os ?? 'Windows 11';
  const targetOs = activeOs === 'Windows 11' ? 'Shift OS' : 'Windows 11';

  const doShift = async () => {
    setShifting(true);
    setPhase(0);
    const start = Date.now();
    const perPhase = mode === 'Instant Switch' ? 450 : mode === 'Warm Bridge' ? 850 : 1400;
    for (let i = 0; i < PHASES.length; i++) {
      setPhase(i);
      await new Promise((r) => setTimeout(r, perPhase));
    }
    try {
      await fetch('/api/osshift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from_os: activeOs,
          to_os: targetOs,
          mode,
          duration_ms: Date.now() - start,
          initiated_by: 'admin@command',
        }),
      });
      await fetchHistory();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setShifting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-[var(--line)] border-t-[var(--neon)]" />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
      {error && (
        <div className="xl:col-span-3 rounded-md border border-[var(--danger)]/40 bg-[var(--danger)]/10 px-4 py-2.5 text-xs text-[var(--danger)]">
          {error}
        </div>
      )}

      <Panel title="OS Handoff Control" tag="dual boot bridge" className="xl:col-span-2">
        {/* OS cards */}
        <div className="grid grid-cols-1 items-center gap-4 sm:grid-cols-[1fr_auto_1fr]">
          {[activeOs, targetOs].map((os, idx) => {
            const meta = osMeta[os];
            const isActive = idx === 0;
            return (
              <div key={os} className={`rounded-lg border p-4 transition-all ${isActive ? 'border-transparent bg-black/30' : 'border-[var(--line)] bg-black/15 opacity-80'}`}
                style={isActive ? { borderColor: `color-mix(in srgb, ${meta.color} 45%, transparent)`, boxShadow: `0 0 24px color-mix(in srgb, ${meta.color} 18%, transparent)` } : undefined}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="grid h-10 w-10 place-items-center rounded-md border border-[var(--line)]" style={{ color: meta.color }}>
                      {os === 'Windows 11' ? <MonitorCog size={19} /> : <Layers size={19} />}
                    </div>
                    <div>
                      <p className="font-display text-[14px] font-bold text-white">{os}</p>
                      <p className="font-mono text-[10px] text-slate-500">{meta.kernel}</p>
                    </div>
                  </div>
                  <span className="rounded-full px-2 py-0.5 font-mono text-[9px] font-bold uppercase tracking-wider"
                    style={isActive ? { color: meta.color, background: `color-mix(in srgb, ${meta.color} 14%, transparent)` } : { color: '#64748b', background: 'rgba(255,255,255,0.04)' }}>
                    {isActive ? 'Active' : 'Standby'}
                  </span>
                </div>
                <p className="mt-3 font-mono text-[10.5px] text-slate-500">{meta.session}</p>
                <div className="mt-2 flex justify-between font-mono text-[10px] text-slate-500 tabular-nums">
                  <span>DEVICES <span className="text-slate-300">6/6</span></span>
                  <span>STATE <span style={{ color: isActive ? 'var(--ok)' : '#64748b' }}>{isActive ? 'RUNNING' : 'SUSPENDED'}</span></span>
                </div>
              </div>
            );
          })}

          {/* center shift button, placed via order on grid */}
          <div className="order-first flex flex-col items-center gap-2 sm:order-none sm:col-start-2 sm:row-start-1">
            <button
              onClick={doShift}
              disabled={shifting}
              className="group relative grid h-16 w-16 place-items-center rounded-full border border-[var(--neon)]/40 bg-[var(--neon)]/10 text-[var(--neon)] transition hover:bg-[var(--neon)]/20 hover:shadow-[0_0_24px_rgba(0,180,255,0.45)] disabled:opacity-60"
            >
              {shifting ? <Loader2 size={24} className="animate-spin" /> : <ArrowLeftRight size={24} />}
              <span className="absolute inset-0 rounded-full border border-[var(--neon)]/20 animate-ping [animation-duration:2.5s]" />
            </button>
            <span className="font-mono text-[9px] font-bold uppercase tracking-widest text-[var(--neon)]">{shifting ? 'Shifting' : 'Shift'}</span>
          </div>
        </div>

        {/* handoff progress */}
        {shifting && (
          <div className="mt-4 rounded-md border border-[var(--neon)]/25 bg-black/30 p-3.5">
            <div className="flex items-center justify-between font-mono text-[10px] uppercase tracking-widest">
              <span className="text-[var(--neon)]">{PHASES[phase]}</span>
              <span className="text-slate-500 tabular-nums">{phase + 1} / {PHASES.length}</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#1a222e]">
              <div className="h-full rounded-full bg-[var(--neon)] shadow-[0_0_10px_var(--neon)] transition-all duration-500" style={{ width: `${((phase + 1) / PHASES.length) * 100}%` }} />
            </div>
          </div>
        )}

        {/* mode selector */}
        <div className="mt-4 border-t border-[var(--line)] pt-4">
          <p className="mb-2 font-mono text-[10px] uppercase tracking-widest text-slate-500">Handoff Mode</p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            {MODES.map((m) => {
              const desc = m === 'Warm Bridge' ? 'Session preserved · ~3.5s' : m === 'Instant Switch' ? 'RAM-resident swap · ~1.8s' : 'Full reboot · ~5.6s';
              const sel = mode === m;
              return (
                <button key={m} onClick={() => setMode(m)} disabled={shifting}
                  className={`rounded-md border px-3 py-2.5 text-left transition ${sel ? 'border-[var(--neon)]/50 bg-[var(--neon)]/10' : 'border-[var(--line)] bg-black/20 hover:border-slate-600'}`}>
                  <p className={`text-[12px] font-semibold ${sel ? 'text-[var(--neon)]' : 'text-slate-300'}`}>{m}</p>
                  <p className="mt-0.5 font-mono text-[9.5px] text-slate-500">{desc}</p>
                </button>
              );
            })}
          </div>
        </div>
      </Panel>

      {/* bridge status */}
      <Panel title="Bridge Status" tag="aes-256-gcm">
        <div className="space-y-3">
          {[
            { icon: Cable, label: 'Tunnel Link', value: 'CONNECTED', color: 'var(--ok)' },
            { icon: ShieldCheck, label: 'Encryption', value: 'AES-256-GCM', color: 'var(--neon)' },
            { icon: Layers, label: 'Device Sync', value: '6 / 6 mirrored', color: 'var(--ok)' },
            { icon: History, label: 'Key Rotation', value: 'every 15 min', color: 'var(--neon)' },
          ].map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="flex items-center justify-between rounded-md border border-[var(--line)] bg-black/25 px-3 py-2.5">
              <span className="flex items-center gap-2 text-[12px] text-slate-400"><Icon size={14} style={{ color }} /> {label}</span>
              <span className="font-mono text-[10.5px] font-bold tabular-nums" style={{ color }}>{value}</span>
            </div>
          ))}
          <div className="rounded-md border border-[var(--line)] bg-black/25 p-3">
            <div className="flex justify-between font-mono text-[10px] uppercase tracking-widest text-slate-500">
              <span>Bridge latency</span><span className="text-[var(--neon)] tabular-nums">0.84 ms</span>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#1a222e]">
              <div className="h-full w-[12%] rounded-full bg-[var(--ok)] shadow-[0_0_8px_var(--ok)]" />
            </div>
            <p className="mt-1.5 font-mono text-[9px] text-slate-600">threshold 8.00 ms · nominal</p>
          </div>
        </div>
      </Panel>

      {/* switch history */}
      <Panel title="Switch History" tag={`${history.length} events`} className="xl:col-span-3">
        {history.length === 0 ? (
          <p className="py-6 text-center text-xs text-slate-500">No OS switches recorded yet. Trigger a shift above.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left">
              <thead>
                <tr className="border-b border-[var(--line)] font-mono text-[9.5px] uppercase tracking-widest text-slate-500">
                  <th className="pb-2 pr-4">Timestamp</th>
                  <th className="pb-2 pr-4">Transition</th>
                  <th className="pb-2 pr-4">Mode</th>
                  <th className="pb-2 pr-4">Duration</th>
                  <th className="pb-2">Initiated By</th>
                </tr>
              </thead>
              <tbody>
                {history.map((h) => (
                  <tr key={h.id} className="border-b border-[var(--line)]/50 text-[12px]">
                    <td className="py-2.5 pr-4 font-mono text-[10.5px] text-slate-500 tabular-nums">{new Date(h.created_at).toLocaleString()}</td>
                    <td className="py-2.5 pr-4">
                      <span style={{ color: osMeta[h.from_os]?.color }}>{h.from_os}</span>
                      <ArrowLeftRight size={11} className="mx-2 inline text-slate-600" />
                      <span style={{ color: osMeta[h.to_os]?.color }} className="font-semibold">{h.to_os}</span>
                    </td>
                    <td className="py-2.5 pr-4 font-mono text-[10.5px] text-slate-400">{h.mode}</td>
                    <td className="py-2.5 pr-4 font-mono text-[10.5px] text-slate-400 tabular-nums">{(h.duration_ms / 1000).toFixed(2)}s</td>
                    <td className="py-2.5 font-mono text-[10.5px] text-slate-500">{h.initiated_by}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Panel>
    </div>
  );
}
