import { useState } from 'react';
import Panel from '../components/Panel';
import HostScan from '../components/HostScan';
import { Meter, AreaChart } from '../components/charts';
import type { LiveMetrics } from '../lib/useMetrics';
import { apiPut, type Device } from '../lib/api';
import { Cpu, MemoryStick, HardDrive, MonitorSmartphone, Fan, Network, Power } from 'lucide-react';

const icons: Record<string, typeof Cpu> = {
  cpu: Cpu, gpu: MonitorSmartphone, memory: MemoryStick, storage: HardDrive, cooling: Fan, network: Network,
};

export default function Devices({ devices, m, refresh }: { devices: Device[]; m: LiveMetrics; refresh: () => void }) {
  const [busy, setBusy] = useState<number | null>(null);

  const toggle = async (d: Device) => {
    setBusy(d.id);
    try {
      await apiPut('/api/devices', { id: d.id, status: d.status === 'offline' ? 'optimal' : 'offline' });
      refresh();
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-4">
      <HostScan />
      <Panel title="Memory Pressure" tag="live">
        <AreaChart data={m.ramHistory} color="#00e5a8" height={64} />
      </Panel>
      <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
        {devices.map((d) => {
          const Icon = icons[d.type] ?? Cpu;
          const off = d.status === 'offline';
          return (
            <Panel key={d.id} title={d.name} tag={d.type}>
              <div className="flex items-start justify-between">
                <div className={`grid h-11 w-11 place-items-center rounded-md border border-[var(--line)] ${off ? 'bg-black/40 text-slate-600' : 'bg-[var(--neon)]/10 text-[var(--neon)]'}`}>
                  <Icon size={20} />
                </div>
                <button
                  onClick={() => toggle(d)}
                  disabled={busy === d.id}
                  className={`flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 font-mono text-[10px] font-bold uppercase tracking-wider transition disabled:opacity-50 ${
                    off ? 'border-[var(--ok)]/40 text-[var(--ok)] hover:bg-[var(--ok)]/10' : 'border-[var(--line)] text-slate-400 hover:border-[var(--danger)]/50 hover:text-[var(--danger)]'
                  }`}
                >
                  <Power size={11} /> {busy === d.id ? '···' : off ? 'Enable' : 'Disable'}
                </button>
              </div>
              <div className="mt-3 space-y-2.5">
                <div>
                  <div className="mb-1 flex justify-between font-mono text-[10px] text-slate-500">
                    <span>UTILIZATION</span><span className="tabular-nums text-slate-300">{off ? 0 : d.usage}%</span>
                  </div>
                  <Meter value={off ? 0 : d.usage} />
                </div>
                <div>
                  <div className="mb-1 flex justify-between font-mono text-[10px] text-slate-500">
                    <span>HEALTH</span><span className="tabular-nums text-slate-300">{d.health}%</span>
                  </div>
                  <Meter value={d.health} color={d.health > 80 ? 'var(--ok)' : d.health > 55 ? 'var(--warn)' : 'var(--danger)'} />
                </div>
                <div className="grid grid-cols-2 gap-2 border-t border-[var(--line)] pt-2.5 font-mono text-[10px] text-slate-500">
                  <div>TEMP <span className="text-slate-300 tabular-nums">{off ? '—' : `${d.temperature}°C`}</span></div>
                  <div className="text-right">FW <span className="text-slate-300">{d.firmware}</span></div>
                  <div>DRIVER <span className="text-slate-300">{d.driver_version}</span></div>
                  <div className="text-right">BIND <span className="text-[var(--neon)]">{d.os_binding}</span></div>
                </div>
              </div>
            </Panel>
          );
        })}
      </div>
    </div>
  );
}
