import Panel from '../components/Panel';
import { AreaChart, Ring, Meter } from '../components/charts';
import type { LiveMetrics } from '../lib/useMetrics';
import { apiPut, type Device, type Alert, type FirmwareUpdate } from '../lib/api';
import { ShieldAlert, ShieldCheck, ChevronRight, HardDriveDownload } from 'lucide-react';

const sevColor: Record<string, string> = { critical: 'var(--danger)', warning: 'var(--warn)', info: 'var(--neon)' };

export default function Overview({ m, devices, alerts, firmware, refresh }: {
  m: LiveMetrics; devices: Device[]; alerts: Alert[]; firmware: FirmwareUpdate[]; refresh: () => void;
}) {
  const active = alerts.filter((a) => !a.resolved).slice(0, 4);
  const pending = firmware.filter((f) => f.status === 'available');

  const resolve = async (id: number) => {
    await apiPut('/api/alerts', { id, resolved: true });
    refresh();
  };

  return (
    <div className="grid grid-cols-1 gap-4 xl:grid-cols-3">
      <Panel title="Live Performance" tag="realtime" className="xl:col-span-2">
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <Ring value={m.cpu} label="CPU Load" sub={`${m.cpuTemp.toFixed(0)}°C · 5.4 GHz`} />
          <Ring value={m.gpu} label="GPU Load" color="#7c5cff" sub={`${m.gpuTemp.toFixed(0)}°C · 2610 MHz`} />
          <Ring value={m.ram} label="Memory" color="#00e5a8" sub={`${((m.ram / 100) * 64).toFixed(1)} / 64 GB`} />
          <Ring value={(m.netDown / 240) * 100} label="Network" color="#ffb020" sub={`↓${m.netDown.toFixed(0)} ↑${m.netUp.toFixed(0)} Mb/s`} />
        </div>
        <div className="mt-5 grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <div className="mb-1 flex justify-between font-mono text-[10px] uppercase tracking-widest text-slate-500">
              <span>CPU · 72s window</span><span className="text-[var(--neon)]">{m.cpu.toFixed(1)}%</span>
            </div>
            <AreaChart data={m.cpuHistory} />
          </div>
          <div>
            <div className="mb-1 flex justify-between font-mono text-[10px] uppercase tracking-widest text-slate-500">
              <span>GPU · 72s window</span><span style={{ color: '#7c5cff' }}>{m.gpu.toFixed(1)}%</span>
            </div>
            <AreaChart data={m.gpuHistory} color="#7c5cff" />
          </div>
        </div>
      </Panel>

      <Panel title="Security Alerts" tag={`${active.length} active`}>
        {active.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-8 text-center">
            <ShieldCheck size={28} className="text-[var(--ok)]" />
            <p className="text-xs text-slate-400">All clear. No active threats detected.</p>
          </div>
        ) : (
          <ul className="space-y-2.5">
            {active.map((a) => (
              <li key={a.id} className="rounded-md border border-[var(--line)] bg-black/25 p-3">
                <div className="flex items-start gap-2.5">
                  <ShieldAlert size={15} style={{ color: sevColor[a.severity] }} className="mt-0.5 shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between gap-2">
                      <p className="truncate text-[12.5px] font-semibold text-slate-200">{a.title}</p>
                      <span className="shrink-0 rounded px-1.5 py-px font-mono text-[9px] font-bold uppercase" style={{ color: sevColor[a.severity], background: `color-mix(in srgb, ${sevColor[a.severity]} 12%, transparent)` }}>
                        {a.severity}
                      </span>
                    </div>
                    <p className="mt-0.5 line-clamp-2 text-[11px] text-slate-500">{a.description}</p>
                    <button onClick={() => resolve(a.id)} className="mt-1.5 text-[10.5px] font-semibold uppercase tracking-wider text-[var(--neon)] hover:underline">
                      Resolve →
                    </button>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel title="Device Health Matrix" tag={`${devices.length} devices`} className="xl:col-span-2">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {devices.slice(0, 6).map((d) => (
            <div key={d.id} className="rounded-md border border-[var(--line)] bg-black/25 p-3">
              <div className="flex items-center justify-between">
                <span className="truncate text-[12.5px] font-semibold text-slate-200">{d.name}</span>
                <span className={`font-mono text-[9px] font-bold uppercase ${d.status === 'optimal' ? 'text-[var(--ok)]' : d.status === 'degraded' ? 'text-[var(--warn)]' : 'text-[var(--danger)]'}`}>
                  {d.status}
                </span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <Meter value={d.health} color={d.health > 80 ? 'var(--ok)' : d.health > 55 ? 'var(--warn)' : 'var(--danger)'} />
                <span className="font-mono text-[10px] text-slate-400 tabular-nums">{d.health}%</span>
              </div>
              <div className="mt-1.5 flex justify-between font-mono text-[10px] text-slate-500 tabular-nums">
                <span>{d.temperature}°C</span>
                <span>{d.os_binding}</span>
              </div>
            </div>
          ))}
        </div>
      </Panel>

      <Panel title="Pending Firmware" tag={`${pending.length} queued`}>
        {pending.length === 0 ? (
          <p className="py-8 text-center text-xs text-slate-500">All firmware up to date.</p>
        ) : (
          <ul className="space-y-2">
            {pending.slice(0, 4).map((f) => (
              <li key={f.id} className="flex items-center gap-3 rounded-md border border-[var(--line)] bg-black/25 p-2.5">
                <HardDriveDownload size={15} className={f.critical ? 'text-[var(--danger)]' : 'text-[var(--neon)]'} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-[12px] font-semibold text-slate-200">{f.component}</p>
                  <p className="font-mono text-[10px] text-slate-500">{f.current_version} <ChevronRight size={9} className="inline" /> <span className="text-[var(--neon)]">{f.available_version}</span></p>
                </div>
                {f.critical && <span className="rounded bg-[var(--danger)]/15 px-1.5 py-px font-mono text-[9px] font-bold uppercase text-[var(--danger)]">crit</span>}
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
