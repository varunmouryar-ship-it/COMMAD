import { useEffect, useRef, useState } from 'react';
import type { Device, Alert, FirmwareUpdate } from '../lib/api';
import type { LiveMetrics } from '../lib/useMetrics';
import { fmtUptime } from '../lib/useMetrics';

interface Line { text: string; kind: 'in' | 'out' | 'err' | 'ok' }

export default function Terminal({ devices, alerts, firmware, m }: { devices: Device[]; alerts: Alert[]; firmware: FirmwareUpdate[]; m: LiveMetrics }) {
  const [lines, setLines] = useState<Line[]>([
    { text: 'Command Advanced Shell v3.8.1 — bridging Windows 11 / Shift OS', kind: 'ok' },
    { text: "Type 'help' for available commands.", kind: 'out' },
  ]);
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [histIdx, setHistIdx] = useState(-1);
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [lines]);

  const print = (arr: Line[]) => setLines((l) => [...l, ...arr]);

  const run = (raw: string) => {
    const cmd = raw.trim();
    print([{ text: `C:\\Command> ${cmd}`, kind: 'in' }]);
    if (!cmd) return;
    setHistory((h) => [cmd, ...h]);
    setHistIdx(-1);
    const [name, ...args] = cmd.toLowerCase().split(/\s+/);

    switch (name) {
      case 'help':
        print([
          { text: 'Available commands:', kind: 'out' },
          { text: '  sysinfo          — hardware & OS summary', kind: 'out' },
          { text: '  devices          — list registered devices', kind: 'out' },
          { text: '  alerts           — list security alerts', kind: 'out' },
          { text: '  firmware         — firmware update queue', kind: 'out' },
          { text: '  perf             — live performance snapshot', kind: 'out' },
          { text: '  ping <host>      — ICMP echo test', kind: 'out' },
          { text: '  sfc /scannow     — system file integrity check', kind: 'out' },
          { text: '  shift bridge     — Shift OS bridge status', kind: 'out' },
          { text: '  clear            — clear terminal', kind: 'out' },
        ]);
        break;
      case 'clear':
        setLines([]);
        break;
      case 'sysinfo':
        print([
          { text: 'Host Name:            WORKSTATION-01', kind: 'out' },
          { text: 'OS Name:              Microsoft Windows 11 Pro 24H2 (build 26100)', kind: 'out' },
          { text: 'Secondary OS:         Shift OS v3.8.1 (bridge-linked)', kind: 'out' },
          { text: 'Processor:            Intel Core i9-14900K, 24 cores @ 5.4 GHz', kind: 'out' },
          { text: 'Physical Memory:      64,536 MB DDR5-6400', kind: 'out' },
          { text: `System Uptime:        ${fmtUptime(m.uptime)}`, kind: 'out' },
          { text: 'Secure Boot:          ENABLED · TPM 2.0 active', kind: 'ok' },
        ]);
        break;
      case 'devices':
        print(devices.map((d) => ({
          text: `  [${String(d.id).padStart(2, '0')}] ${d.name.padEnd(28)} ${d.status.padEnd(9)} health:${d.health}%  temp:${d.temperature}°C  bind:${d.os_binding}`,
          kind: d.status === 'optimal' ? 'ok' : d.status === 'offline' ? 'err' : 'out',
        } as Line)));
        break;
      case 'alerts': {
        const act = alerts.filter((a) => !a.resolved);
        print(act.length === 0
          ? [{ text: 'No active security alerts.', kind: 'ok' }]
          : act.map((a) => ({ text: `  [${a.severity.toUpperCase()}] ${a.title} — ${a.source}`, kind: a.severity === 'critical' ? 'err' : 'out' } as Line)));
        break;
      }
      case 'firmware':
        print(firmware.map((f) => ({
          text: `  ${f.component.padEnd(26)} ${f.current_version.padEnd(12)} ${f.status === 'available' ? `→ ${f.available_version} AVAILABLE${f.critical ? ' [CRITICAL]' : ''}` : f.status.toUpperCase()}`,
          kind: f.status === 'available' ? (f.critical ? 'err' : 'out') : 'ok',
        } as Line)));
        break;
      case 'perf':
        print([
          { text: `  CPU: ${m.cpu.toFixed(1)}%  (${m.cpuTemp.toFixed(0)}°C)`, kind: 'out' },
          { text: `  GPU: ${m.gpu.toFixed(1)}%  (${m.gpuTemp.toFixed(0)}°C)`, kind: 'out' },
          { text: `  RAM: ${m.ram.toFixed(1)}%  (${((m.ram / 100) * 64).toFixed(1)} / 64 GB)`, kind: 'out' },
          { text: `  NET: ↓${m.netDown.toFixed(0)} Mb/s  ↑${m.netUp.toFixed(0)} Mb/s`, kind: 'out' },
        ]);
        break;
      case 'ping': {
        const host = args[0] || 'shift-bridge.local';
        print([
          { text: `Pinging ${host} with 32 bytes of data:`, kind: 'out' },
          ...Array.from({ length: 4 }, () => ({ text: `Reply from ${host}: bytes=32 time=${(Math.random() * 8 + 1).toFixed(0)}ms TTL=128`, kind: 'out' } as Line)),
          { text: `Packets: Sent = 4, Received = 4, Lost = 0 (0% loss)`, kind: 'ok' },
        ]);
        break;
      }
      case 'sfc':
        print([
          { text: 'Beginning system scan. This process will take some time.', kind: 'out' },
          { text: 'Verification 100% complete.', kind: 'out' },
          { text: 'Windows Resource Protection did not find any integrity violations.', kind: 'ok' },
        ]);
        break;
      case 'shift':
        print([
          { text: 'Shift OS Bridge — status report', kind: 'out' },
          { text: '  Link state:      CONNECTED (encrypted tunnel, AES-256-GCM)', kind: 'ok' },
          { text: '  Kernel version:  shift-3.8.1-lts', kind: 'out' },
          { text: '  Shared devices:  6 / 6 synchronized', kind: 'out' },
          { text: `  Latency:         ${(Math.random() * 2 + 0.4).toFixed(2)} ms`, kind: 'out' },
        ]);
        break;
      default:
        print([{ text: `'${name}' is not recognized as an internal or external command. Type 'help'.`, kind: 'err' }]);
    }
  };

  const kindClass: Record<Line['kind'], string> = {
    in: 'text-slate-300', out: 'text-slate-400', err: 'text-[var(--danger)]', ok: 'text-[var(--ok)]',
  };

  return (
    <div className="mx-auto max-w-5xl">
      <div className="overflow-hidden rounded-lg border border-[var(--line)] bg-[#05080d] shadow-[0_4px_32px_rgba(0,0,0,0.5)]">
        <div className="flex items-center justify-between border-b border-[var(--line)] bg-[var(--panel)] px-4 py-2.5">
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-[var(--danger)]/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-[var(--warn)]/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-[var(--ok)]/70" />
          </div>
          <span className="font-mono text-[10px] uppercase tracking-widest text-slate-500">command — advanced shell — 120×32</span>
          <span className="font-mono text-[10px] text-[var(--neon)]">ADMIN</span>
        </div>
        <div className="h-[62vh] overflow-y-auto p-4 font-mono text-[12px] leading-relaxed" onClick={() => inputRef.current?.focus()}>
          {lines.map((l, i) => (
            <div key={i} className={`whitespace-pre-wrap ${kindClass[l.kind]}`}>{l.text}</div>
          ))}
          <div className="flex items-center gap-0">
            <span className="text-[var(--neon)]">C:\Command&gt;&nbsp;</span>
            <input
              ref={inputRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') { run(input); setInput(''); }
                if (e.key === 'ArrowUp') { e.preventDefault(); const i = Math.min(histIdx + 1, history.length - 1); if (history[i]) { setHistIdx(i); setInput(history[i]); } }
                if (e.key === 'ArrowDown') { e.preventDefault(); const i = histIdx - 1; setHistIdx(i); setInput(i >= 0 ? history[i] : ''); }
              }}
              className="flex-1 bg-transparent text-slate-200 caret-[var(--neon)] outline-none"
              autoFocus spellCheck={false} autoComplete="off"
            />
          </div>
          <div ref={endRef} />
        </div>
      </div>
      <p className="mt-3 text-center font-mono text-[10px] uppercase tracking-widest text-slate-600">
        try: sysinfo · devices · alerts · firmware · perf · ping · shift bridge
      </p>
    </div>
  );
}
