import { useState } from 'react';
import Panel from '../components/Panel';
import { apiPut, type FirmwareUpdate } from '../lib/api';
import { HardDriveDownload, CheckCircle2, AlertTriangle, Loader2, ChevronRight, RefreshCw } from 'lucide-react';

export default function Firmware({ firmware, refresh }: { firmware: FirmwareUpdate[]; refresh: () => void }) {
  const [installing, setInstalling] = useState<Set<number>>(new Set());

  const install = async (f: FirmwareUpdate) => {
    setInstalling((s) => new Set(s).add(f.id));
    await apiPut('/api/firmware', { id: f.id, status: 'installing' });
    refresh();
    // simulate flash duration, then finalize
    setTimeout(async () => {
      await apiPut('/api/firmware', { id: f.id, status: 'installed', current_version: f.available_version });
      setInstalling((s) => { const n = new Set(s); n.delete(f.id); return n; });
      refresh();
    }, 3500);
  };

  const available = firmware.filter((f) => f.status === 'available' || f.status === 'installing').length;

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {[
          { label: 'Components Tracked', value: firmware.length, color: 'var(--neon)' },
          { label: 'Updates Pending', value: available, color: 'var(--warn)' },
          { label: 'Critical Patches', value: firmware.filter((f) => f.critical && f.status === 'available').length, color: 'var(--danger)' },
          { label: 'Up To Date', value: firmware.filter((f) => f.status === 'up-to-date' || f.status === 'installed').length, color: 'var(--ok)' },
        ].map((s) => (
          <div key={s.label} className="rounded-lg border border-[var(--line)] bg-[var(--panel)] p-4">
            <div className="font-display text-2xl font-bold tabular-nums" style={{ color: s.color }}>{s.value}</div>
            <div className="mt-0.5 text-[10px] uppercase tracking-widest text-slate-500">{s.label}</div>
          </div>
        ))}
      </div>

      <Panel
        title="BIOS & Firmware Repository"
        tag="UEFI capsule"
        action={
          <button onClick={refresh} className="flex items-center gap-1.5 rounded-md border border-[var(--line)] px-2.5 py-1 font-mono text-[10px] uppercase tracking-wider text-slate-400 hover:border-[var(--neon)]/40 hover:text-[var(--neon)]">
            <RefreshCw size={11} /> Scan
          </button>
        }
      >
        <div className="space-y-2.5">
          {firmware.map((f) => {
            const isInstalling = f.status === 'installing' || installing.has(f.id);
            const done = f.status === 'up-to-date' || f.status === 'installed';
            return (
              <div key={f.id} className="rounded-md border border-[var(--line)] bg-black/25 p-3.5">
                <div className="flex flex-wrap items-center gap-3">
                  <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-md border border-[var(--line)] ${done ? 'text-[var(--ok)]' : f.critical ? 'text-[var(--danger)]' : 'text-[var(--neon)]'}`}>
                    {done ? <CheckCircle2 size={18} /> : isInstalling ? <Loader2 size={18} className="animate-spin" /> : f.critical ? <AlertTriangle size={18} /> : <HardDriveDownload size={18} />}
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-[13px] font-semibold text-slate-200">{f.component}</span>
                      <span className="font-mono text-[10px] text-slate-500">{f.vendor}</span>
                      {f.critical && !done && <span className="rounded bg-[var(--danger)]/15 px-1.5 py-px font-mono text-[9px] font-bold uppercase text-[var(--danger)]">critical</span>}
                    </div>
                    <div className="mt-0.5 flex items-center gap-1.5 font-mono text-[11px] text-slate-500 tabular-nums">
                      <span>{f.current_version}</span>
                      {!done && (<><ChevronRight size={10} /><span className="text-[var(--neon)]">{f.available_version}</span><span className="text-slate-600">· {f.size_mb} MB</span></>)}
                    </div>
                    <p className="mt-1 line-clamp-1 text-[11px] text-slate-500">{f.changelog}</p>
                  </div>
                  <div className="shrink-0">
                    {done ? (
                      <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-[var(--ok)]">✓ current</span>
                    ) : isInstalling ? (
                      <div className="w-28">
                        <div className="h-1.5 overflow-hidden rounded-full bg-[#1a222e]">
                          <div className="h-full w-full origin-left animate-[flash_3.5s_linear] rounded-full bg-[var(--neon)] shadow-[0_0_8px_var(--neon)]" />
                        </div>
                        <p className="mt-1 text-center font-mono text-[9px] uppercase text-[var(--neon)]">flashing…</p>
                      </div>
                    ) : (
                      <button onClick={() => install(f)} className="rounded-md border border-[var(--neon)]/40 bg-[var(--neon)]/10 px-3.5 py-1.5 font-mono text-[10px] font-bold uppercase tracking-wider text-[var(--neon)] transition hover:bg-[var(--neon)]/20 hover:shadow-[0_0_12px_rgba(0,180,255,0.3)]">
                        Flash Update
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </Panel>
    </div>
  );
}
