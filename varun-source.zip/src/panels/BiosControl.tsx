import { useMemo, useState } from 'react';
import Panel from '../components/Panel';
import { apiPut, type BiosSetting } from '../lib/api';
import { Lock, Unlock, ShieldCheck } from 'lucide-react';

export default function BiosControl({ settings, refresh }: { settings: BiosSetting[]; refresh: () => void }) {
  const [unlocked, setUnlocked] = useState(false);
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState('');
  const [saving, setSaving] = useState<number | null>(null);

  const categories = useMemo(() => {
    const map = new Map<string, BiosSetting[]>();
    settings.forEach((s) => map.set(s.category, [...(map.get(s.category) ?? []), s]));
    return [...map.entries()];
  }, [settings]);

  const unlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (pin === '0000') { setUnlocked(true); setPinError(''); }
    else setPinError('Invalid access PIN. Hint: default admin PIN is 0000.');
  };

  const update = async (s: BiosSetting, value: string) => {
    setSaving(s.id);
    try { await apiPut('/api/bios', { id: s.id, value }); refresh(); }
    finally { setSaving(null); }
  };

  if (!unlocked) {
    return (
      <div className="mx-auto mt-12 max-w-sm">
        <Panel title="BIOS Access Gate" tag="restricted">
          <div className="flex flex-col items-center gap-3 py-4 text-center">
            <div className="grid h-14 w-14 place-items-center rounded-full border border-[var(--warn)]/40 bg-[var(--warn)]/10">
              <Lock size={22} className="text-[var(--warn)]" />
            </div>
            <p className="text-[12.5px] text-slate-400">Firmware-level settings require elevated authorization. Enter the administrator PIN to proceed.</p>
            <form onSubmit={unlock} className="w-full space-y-3">
              <input
                type="password" inputMode="numeric" maxLength={4} value={pin}
                onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))}
                placeholder="••••"
                className="w-full rounded-md border border-[var(--line)] bg-black/40 px-3 py-2.5 text-center font-mono text-lg tracking-[0.5em] text-[var(--neon)] outline-none placeholder:text-slate-600 focus:border-[var(--neon)]/50"
              />
              {pinError && <p className="text-[11px] text-[var(--danger)]">{pinError}</p>}
              <button type="submit" disabled={pin.length !== 4} className="w-full rounded-md border border-[var(--neon)]/40 bg-[var(--neon)]/10 py-2.5 font-mono text-[11px] font-bold uppercase tracking-widest text-[var(--neon)] transition hover:bg-[var(--neon)]/20 disabled:opacity-40">
                Authorize Access
              </button>
            </form>
          </div>
        </Panel>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between rounded-lg border border-[var(--ok)]/30 bg-[var(--ok)]/10 px-4 py-3">
        <div className="flex items-center gap-2.5">
          <ShieldCheck size={17} className="text-[var(--ok)]" />
          <span className="text-[12.5px] font-semibold text-[var(--ok)]">Elevated session active — UEFI settings unlocked. Changes persist to firmware store.</span>
        </div>
        <button onClick={() => { setUnlocked(false); setPin(''); }} className="flex items-center gap-1.5 rounded-md border border-[var(--line)] px-2.5 py-1 font-mono text-[10px] uppercase text-slate-400 hover:text-slate-200">
          <Unlock size={11} /> Lock
        </button>
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {categories.map(([cat, items]) => (
          <Panel key={cat} title={cat} tag={`${items.length} keys`}>
            <div className="space-y-3">
              {items.map((s) => (
                <div key={s.id} className="flex items-center justify-between gap-4 rounded-md border border-[var(--line)] bg-black/25 px-3 py-2.5">
                  <div className="min-w-0">
                    <p className="text-[12.5px] font-semibold text-slate-200">{s.label}</p>
                    <p className="mt-0.5 line-clamp-1 text-[10.5px] text-slate-500">{s.description}</p>
                    <p className="font-mono text-[9px] uppercase text-slate-600">{s.setting_key}</p>
                  </div>
                  <div className="shrink-0">
                    {s.value_type === 'bool' ? (
                      <button
                        onClick={() => update(s, s.value === 'true' ? 'false' : 'true')}
                        disabled={saving === s.id}
                        className={`relative h-6 w-11 rounded-full transition ${s.value === 'true' ? 'bg-[var(--neon)]/80 shadow-[0_0_10px_rgba(0,180,255,0.4)]' : 'bg-[#1a222e]'} disabled:opacity-50`}
                      >
                        <span className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all ${s.value === 'true' ? 'left-[22px]' : 'left-0.5'}`} />
                      </button>
                    ) : s.value_type === 'select' && s.options ? (
                      <select
                        value={s.value}
                        disabled={saving === s.id}
                        onChange={(e) => update(s, e.target.value)}
                        className="rounded-md border border-[var(--line)] bg-black/50 px-2 py-1.5 font-mono text-[11px] text-[var(--neon)] outline-none focus:border-[var(--neon)]/50"
                      >
                        {s.options.map((o) => <option key={o} value={o}>{o}</option>)}
                      </select>
                    ) : (
                      <input
                        type="number" defaultValue={s.value} disabled={saving === s.id}
                        onBlur={(e) => e.target.value !== s.value && update(s, e.target.value)}
                        className="w-20 rounded-md border border-[var(--line)] bg-black/50 px-2 py-1.5 text-right font-mono text-[11px] text-[var(--neon)] outline-none focus:border-[var(--neon)]/50"
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </Panel>
        ))}
      </div>
    </div>
  );
}
