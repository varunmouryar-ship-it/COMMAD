import { useCallback, useEffect, useState } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import GithubGuide from './pages/GithubGuide';
import Sidebar, { type View } from './components/Sidebar';
import TopBar from './components/TopBar';
import Overview from './panels/Overview';
import OsShift from './panels/OsShift';
import Devices from './panels/Devices';
import Firmware from './panels/Firmware';
import BiosControl from './panels/BiosControl';
import Terminal from './panels/Terminal';
import Diagnostics from './panels/Diagnostics';
import { useMetrics } from './lib/useMetrics';
import { apiGet, type Device, type Alert, type FirmwareUpdate, type DiagnosticTest, type BiosSetting } from './lib/api';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/github-guide" element={<GithubGuide />} />
        <Route path="*" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  );
}

function Dashboard() {
  const [view, setView] = useState<View>('overview');
  const metrics = useMetrics();

  const [devices, setDevices] = useState<Device[]>([]);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [firmware, setFirmware] = useState<FirmwareUpdate[]>([]);
  const [tests, setTests] = useState<DiagnosticTest[]>([]);
  const [bios, setBios] = useState<BiosSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAll = useCallback(async () => {
    try {
      const [d, a, f, t, b] = await Promise.all([
        apiGet<Device[]>('/api/devices'),
        apiGet<Alert[]>('/api/alerts'),
        apiGet<FirmwareUpdate[]>('/api/firmware'),
        apiGet<DiagnosticTest[]>('/api/diagnostics'),
        apiGet<BiosSetting[]>('/api/bios'),
      ]);
      setDevices(d); setAlerts(a); setFirmware(f); setTests(t); setBios(b);
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const activeAlerts = alerts.filter((a) => !a.resolved).length;

  return (
    <div className="flex h-screen overflow-hidden bg-[var(--bg)] text-slate-300">
      <Sidebar view={view} setView={setView} />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar m={metrics} alertCount={activeAlerts} />
        <main className="relative flex-1 overflow-y-auto p-4 lg:p-6">
          <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(0,180,255,0.05),transparent_55%)]" />
          {loading ? (
            <div className="flex h-full flex-col items-center justify-center gap-3">
              <div className="h-9 w-9 animate-spin rounded-full border-2 border-[var(--line)] border-t-[var(--neon)]" />
              <p className="font-mono text-xs uppercase tracking-widest text-slate-500">Establishing system link…</p>
            </div>
          ) : error ? (
            <div className="mx-auto mt-20 max-w-md rounded-lg border border-[var(--danger)]/40 bg-[var(--danger)]/10 p-6 text-center">
              <p className="font-display font-semibold text-[var(--danger)]">Connection Fault</p>
              <p className="mt-1 text-xs text-slate-400">{error}</p>
              <button onClick={() => { setLoading(true); fetchAll(); }} className="mt-4 rounded-md border border-[var(--neon)]/40 bg-[var(--neon)]/10 px-4 py-1.5 text-xs font-semibold text-[var(--neon)] hover:bg-[var(--neon)]/20">
                Retry Link
              </button>
            </div>
          ) : (
            <div className="relative">
              {view === 'overview' && <Overview m={metrics} devices={devices} alerts={alerts} firmware={firmware} refresh={fetchAll} />}
              {view === 'osshift' && <OsShift />}
              {view === 'devices' && <Devices devices={devices} m={metrics} refresh={fetchAll} />}
              {view === 'firmware' && <Firmware firmware={firmware} refresh={fetchAll} />}
              {view === 'bios' && <BiosControl settings={bios} refresh={fetchAll} />}
              {view === 'terminal' && <Terminal devices={devices} alerts={alerts} firmware={firmware} m={metrics} />}
              {view === 'diagnostics' && <Diagnostics tests={tests} refresh={fetchAll} />}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
